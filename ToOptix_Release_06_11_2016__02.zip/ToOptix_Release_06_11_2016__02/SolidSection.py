"""
.. module:: SolidSection
    :platform: Unix, Windows Linux
    :synopsis: Modul which geometric Functions

.. module:: Martin Denk <denkmartin@web.de>


"""

class SolidSection(object):
    """ Solid sections (defined)

    :param id(int): ID of solid section
    :param material(material): Material object
    :param elset(elset): Elementset object

    Example for creating a a material ( Steel with 210 GPa (20 C) elastic modul)

    >>> aluminium = Material(1,70000)
    >>> eset = Elset(1, "beam", [elem1,elem2,elem3])
    >>> s1 = SolidSection(1, aluminium, eset)

    """

    def __init__(self,ID=None, Material = None, Elset = None):
        self.__material = Material
        self.__elset = Elset
        self.__id = ID

        @property
        def id(self):
            return self.__id

        @id.setter
        def id(self, ID):
            self.__id = ID

        @property
        def material(self):
            return self.__material

        @ material.setter
        def material(self,  material):
            self.__material = material

        @property
        def elset(self):
            return self.__elset

        @elset.setter
        def element_set(self, elset):
            self.__element_set = elset

