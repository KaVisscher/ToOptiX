"""
.. module:: Files
    :platform: Unix, Windows Linux
    :synopsis: Modul which translates files "STL"

"""



from . import Elset
from . import Geometry
from . import File
from . import Material
from . import SolidSection
from . import TopologyOptimization

import shutil
import time
import subprocess
import os
import numpy as np


def sort_element_to_node_dic(elemDic):
    ''' The following function is used for selecting elements around an elem.

    I: Dictonary: [elementID] [Class: Element]

    '''
    # Saves [node] = [elem1, elem2, elem3 ...]
    nodeElem = {}
    # Saves [elemID] = [[elemIDFilt][scaleFac]]
    elemScale = {}
    # This factor sets the purgency
    # The selected element will weight 0.5
    weightOwnElem = 0.5
    for elemID in elemDic:
        element = elemDic[elemID]
        nodeList = element.nodeList
        for node in nodeList:
            try:
                nodeElem[node.id].add(element.id)
            except:
                nodeElem[node.id] = set()
                nodeElem[node.id].add(element.id)

    # Scaling the distances and
    for elemID in elemDic:
        elementInRegion = set()
        element = elemDic[elemID]
        xc = element.xc
        yc = element.yc
        zc = element.zc
        nodeList = element.nodeList
        for node in nodeList:
            elementInRegion = elementInRegion | nodeElem[node.id]
        dist = []
        eleList = []
        # Element for filtering 2 lists with elemID and 1/distance
        for elemR in elementInRegion:
            element1 = elemDic[elemR]
            xc1 = element1.xc
            yc1 = element1.yc
            zc1 = element1.zc
            ele1ID = element1.id
            if ele1ID == element.id:
                continue
            dist.append(1/((xc1-xc)**2 + (yc1-yc)**2 + (zc1-zc)**2)**0.5)
            eleList.append(ele1ID)
        norm = 0
        for distan in dist:
            norm = distan + norm
        distNorm = []
        for distnorm in dist:
            distNorm.append((1-weightOwnElem) * 1/norm * (distnorm))
        distNorm.append(weightOwnElem)
        eleList.append(element.id)
        elemScale[elemID] = [distNorm, eleList]
    return elemScale





def topology_optimization(volfrac, penal, matSets, numbIterAfter, physics, inp_path_static, work_path, solver_path):


    # ----- Input part

    # File paths
    #inp_path_static = "static.inp"
    inp_path_therm = "therm.inp"
    inp_path_buckel = "buckel.inp"
    #solver_path = "solver\\ccx"
    work_path += "fem_calculation"

    # Conrtoll of optimization process
    ##physics = ["static", "heat transfer", "buckling"]
    number_of_iterations = numbIterAfter # Number of iterations during the whole process
    compaction_filter = 0.5 # Density value which decides which elements are in the solution_criteria
    vol_ratio = volfrac # Volumina ratio which is chosen
    mat_number = matSets # Number of sets
    penalty_factor = penal # Penalty exponent
    # ----- Input part
    static_job_inp = inp_path_static.split("\\")
    static_job_inp = static_job_inp[len(static_job_inp) - 1]
    # Get only the job names without extension
    inp_job_static = static_job_inp.split(".inp")[0]

    inp_job_therm = inp_path_therm.split(".inp")[0]
    inp_job_buckel = inp_path_buckel.split(".inp")[0]

    # create new dictonary for the working path
    if os.path.isdir(work_path):
        shutil.rmtree(work_path)
        os.mkdir(work_path)
    else:
        os.mkdir(work_path)

    # Check if one physic is selected
    if len(physics) == 0:
        raise ValueError("No physic is selected")
    elif len(physics) == 1:
        print("Single physic optimization")
    else:
        print("Multi physic with %f different physic types", len(physics))

    # Creating the filenames which are needed
    job_name_system = []
    job_name_sensitivity = []
    for physic in physics:
        job_name_system.append(work_path + "/" + physic + ".ccx")
        job_name_sensitivity.append(work_path + "/" + physic + ".ccx")

    for physic in physics:
        if physic == "static":
            # Importing DATA from CCX-File
            ccx_file = File.CCX_Inp_File(1, inp_path_static)
            ccx_file.read()
            break
        if physic == "heat transfer":
            # Importing DATA from CCX-File
            ccx_file = File.CCX_Inp_File(1, inp_path_therm)
            ccx_file.read()
            break
        if physic == "buckling":
            # Importing DATA from CCX-File
            ccx_file = File.CCX_Inp_File(1, inp_path_buckel)
            ccx_file.read()
            break

    # Define equal compactions
    for elem in ccx_file.elements:
        elem.compaction = 1.0

    # Generating the material Model
    mat_models = []

    # Define material models from given file-object
    for s_section in ccx_file.solid_sections:
        mat_model = TopologyOptimization.MaterialModel()
        mat_model.set_number = mat_number
        mat_model.penalty_factor = penalty_factor
        mat_model.material = s_section.material
        mat_model.elset = s_section.elset
        mat_model.define_topo_materials()
        mat_models.append(mat_model)


    print(("Used different materials for different sections: ", len(mat_models)))
    print("Method of moving asymptotes is selected")
    mma = TopologyOptimization.MethodOfMovingAsymptotes()
    

    # Building up filter-matrix structure
    tmp_dic = {}
    for elem in ccx_file.elements:
        tmp_dic[elem.id] = elem

    print("Creating filter matrix structure")
    filter_struc = sort_element_to_node_dic(tmp_dic)


    for i in range(number_of_iterations):

         # Do topology optimization for each physic type (after that we can combine them)
         for physic in physics:
             if physic == "static":

                 # Run the analysis with material distribution
                 for mat_model in mat_models:
                     mat_model.define_sets_for_material_distribution()
                 ccx_static = File.CCX_Inp_File(1, inp_path_static)
                 print("Exporting the file for static analysis")
                 
                 # Export part and exporting a new inputdeck with a new material law
                 export_path = work_path + "/" + "tp_ana" + static_job_inp
                 ccx_static.export_mod_inp_topo_mat(export_path, mat_models, ccx_file.nodes, "u")
                 s_cmd = solver_path + " " + work_path + "\\" + "tp_ana" + inp_job_static # Command of the console calling
                 os.system(s_cmd) # Call the console
                 
                 # Adding results to nodes
                 dat_file = File.CCX_Dat_File(1, work_path + "\\tp_ana" + inp_job_static + ".dat")
                 dat_file.add_results(ccx_file.nodes, ccx_file.elements,  ["u"])

                 # Creating new input deck for sensitivtiy
                 export_path = work_path + "/" + "tp_sens" + static_job_inp
                 ccx_static.export_mod_inp_topo_sens(export_path, ccx_file.nodes, ccx_file.elements, "ener")

                 # Running sensivitity analysis
                 s_cmd = solver_path + " " + work_path + "\\" + "tp_sens" + inp_job_static
                 os.system(s_cmd)

                 # Adding results to elements
                 dat_file_sens = File.CCX_Dat_File(1, work_path + "\\tp_sens" + inp_job_static + ".dat")
                 dat_file_sens.add_results(ccx_file.nodes, ccx_file.elements, ["ener"])

             elif physic == "heat transfer":
                 pass
             elif physic == "buckling":
                 pass





         # Converting the current data structure in lists (for calculatinon with MMA)
         compaction = []
         sensitivity = []
         tmp_dic = {}

         for elem in ccx_file.elements:
             tmp_dic[elem.id] = elem

         # Filtering the sensitiitys ...

         for elemID in tmp_dic:
             filterList = filter_struc[elemID]
             scaleList = filterList[0]
             eleIDList = filterList[1]
             counter = 0
             scaledSens = 0.0
             for eleID in eleIDList:
                 scaledSens += scaleList[counter] * tmp_dic[eleID].ener
                 counter += 1
             compaction.append(tmp_dic[eleID].compaction)
             sensitivity.append(scaledSens)

         # Controling v_ratio
         print("Volumina Ratio", vol_ratio)
         mma.vol_ratio = vol_ratio
         mma.change_compaction(compaction, sensitivity, mat_models)
         print ("Mean density of all elements", np.mean(mma.compaction))
         count = 0
         for key in tmp_dic:
             tmp_dic[key].compaction = mma.compaction[count]
             count += 1

         # Decide which elements are result elements and which are not
         res_elem = []
         for elem in ccx_file.elements:
             if compaction_filter <= elem.compaction:
                 res_elem.append(elem)
         topo_surf = Geometry.Surface()
         topo_surf.create_surface_on_elements(res_elem)
         # Export into an stl-file
         stl_file = File.STL(1)
         topo_part = Geometry.Solid(1, topo_surf.triangles)
         stl_file.parts.append(topo_part)
         print ("Exporting result result elements", len(res_elem))
         stl_file.write(work_path + "\\tp_surf" + inp_job_static +  str(i) + ".stl")



#topology_optimization(0.3, 3, 10, 5, ["static"], "static.inp", "", "ccx.exe")






