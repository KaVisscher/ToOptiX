"""
.. module:: Material
    :platform: Unix, Windows Linux
    :synopsis: Modul which geometric Functions

.. module:: Martin Denk <denkmartin@web.de>


"""


class Material(object):
    """ Material with different attributes

    :param id(int): Point ID
    :param name(string): Name of the material
    :param e_modul(float): elastic modul


    Example for creating a a material ( Steel with 210 GPa (20 C) elastic modul)

    >>> steel = Material(1, "steel")
    >>> stell.e_modul = ["210000, 20.0"]

    """

    def __init__(self,ID=None, Name=None):
        self.__name = Name
        self.__e_modul = []
        self.__density = []
        self.__conductivity = []
        self.__id = ID

    @property
    def id(self):
        return self.__id

    @ id.setter
    def id(self, ID):
        self.__id = ID

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, name):
        self.__name = name

    @property
    def e_modul(self):
        return self.__e_modul

    @e_modul.setter
    def e_modul(self, e_modul):
        self.__e_modul = e_modul

    @property
    def density(self):
        return self.__density

    @density.setter
    def density(self, density):
        self.__density = density

    @property
    def conductivity(self):
        return self.__conductivity

    @ conductivity.setter
    def conductivity(self, conductivity):
        self.__conductivity = conductivity