"""
.. module:: Elset
    :platform: Unix, Windows Linux
    :synopsis: Modul which geometric Functions

.. module:: Martin Denk <denkmartin@web.de>


"""

class Elset(object):
    """ Define an element set

    :param id(int): ID of element set
    :param name(str): Name of the elementset
    :param elements(list): List of element objects

    Example for creating a a material ( Steel with 210 GPa (20 C) elastic modul)

    >>> e1 = (1, beam, [e1,e2,e3,e4,e5])

    """

    def __init__(self,ID=None, Name = None, Elements = None, Sets = None):
        self.__name = Name
        self.__elements = Elements
        self.__sets = Sets
        self.__id = ID


        @property
        def sets(self):
            return self.__sets

        @sets.setter
        def sets(self, Sets):
            self.__sets = Sets

        @property
        def id(self):
            return self.__id

        @id.setter
        def id(self, ID):
            self.__id = ID

        @property
        def name(self):
            return self.__name

        @ name.setter
        def name(self,  name):
            self.__name = name

        @property
        def elements(self):
            return self.__elements

        @elements.setter
        def elements(self, elements):
            self.__elements = elements

