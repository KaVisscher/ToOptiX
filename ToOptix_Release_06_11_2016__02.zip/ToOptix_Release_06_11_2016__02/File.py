"""
.. module:: File
    :platform: Unix, Windows Linux
    :synopsis: Modul which geometric Functions

.. module:: Martin Denk <denkmartin@web.de>


"""
from . import Geometry
from . import Material
from . import Elset
from . import SolidSection
import os
import re

class File(object):
    """ File-object

    Example for a file definition

    >>> file1 = File(1, "foo.txt")
    """

    def __init__(self,ID=None, Filepath=None):
        self.__filepath = Filepath
        self.__id = ID

    @property
    def id(self):
        return self.__id

    @ id.setter
    def id(self, ID):
        self.__id = ID

    @property
    def filepath(self):
        return self.__filepath

    @filepath.setter
    def filepath(self, filepath):
        self.__filepath = filepath

class STL(File):
    """ STL-File with geometric data

    :param ID (int): Id of the file
    :param Filepath (str): Path of the file

    Example for creating an stl-object

    >>> file1 = STL(1, "./foo.stl")
    >>> part = file.parts[0]

    .. note::
        The file will automatically import the results if the file is given
        Otherwise you need to call import_stl
    """
    def __init__(self, ID=None, Filepath=None):
        File.__init__(self, ID, Filepath)
        self.__parts = []
        # If file is given the importin will started
        if self.filepath:
            self.read()

    @property
    def parts(self):
        """
        :return: All solid objects which are imported
        """
        return self.__parts

    def write(self, filename):
        """ This method can export the current data into an stl-file

        """
        if os.path.isfile(filename):
            raise ValueError ("File does exist alread %f", filename)
        print("Export stl in", filename)
        o_file = open(filename,"w")
        for part in self.parts:
            solid = part
            o_file.write("solid Exported from DMST-STL\n")
            for triangle in solid.triangles:
                #o_file.write("facet " + str(triangle.normal[0]) + " " + str(triangle.normal[1]) + " " + str(triangle.normal[2]) + "\n")
                o_file.write("outer loop\n")
                for point in triangle.points:
                    o_file.write("vertex " + str(point.x) + " " + str(point.y) + " " + str(point.z) + "\n")
                o_file.write("endloop\n")
                #o_file.write("endfacet\n")
            o_file.write("endsolid\n")

    def read(self):
        """ This method imports the geometry to the parts attribute

        """

        if not os.path.isfile(self.filepath):
            raise ValueError ("Given file doesnt exist %f", self.filepath)
        i_file = open(self.filepath, "r")

        # Patterns which are needed
        s_pat = "solid"
        l_pat = "outer loop"
        f_pat = "facet"
        p_pat = "vertex"

        f_e_pat = "endfacet"
        s_e_pat = "endsolid"
        l_e_pat = "endloop"

        solid_is_found = False
        facet_is_found = False
        loop_is_found = False
        id_s = 0 # ID of the solid
        id_t = 0 # ID for triangles
        id_p = 0 # ID for points

        tmp_p_list = [] # Saves all found points
        id_p_old = 0 #ID for points

        # Reading the file
        for line in i_file:
            line = line[0:-1]

            # Solid is found

            if re.match(s_pat, line, 2):
                id_s +=1
                s = Solid(id_s, [])
                self.parts.append(s)
                solid_is_found = True
                continue
            # Solid is closed
            if re.match(s_e_pat, line, 2):
                solid_is_found = False
                continue

            # Facet is found
            if re.match(f_pat, line,2) and solid_is_found:
                id_t += 1
                facet_is_found = True
                t = Geometry.Triangle(id_t, [])
                words = line.split(" ")
                nx = float(words[0])
                ny = float(words[1])
                nz = float(words[2])
                t.normal = [nx, ny, nz]
                s.triangles.append(t)
                continue
            # Facet is closed
            if re.match(f_e_pat, line,2) and solid_is_found and facet_is_found:

                facet_is_found = False
                continue

            # Loop is found
            if re.match(l_pat, line,2) and solid_is_found and facet_is_found:
                loop_is_found = True
                continue
            # Loop is closed
            if re.match(l_e_pat, line,2) and solid_is_found and facet_is_found and loop_is_found:
                loop_is_found = False
                continue

            # Vertex is found
            if re.match(p_pat, line,2) and solid_is_found and facet_is_found and loop_is_found:
                # Finding new point coord
                words = line.split(" ")
                x = float(words[1])
                y = float(words[2])
                z = float(words[3])

                # Checking if point_id exists already
                # If the point_id is found choose the same ID
                p_is_found = False
                controll_count = 0
                for t_p in tmp_p_list:
                    if t_p.x == x and t_p.y == y and t_p.z == z:
                        id_p_old = t_p.id
                        controll_count += 1
                        p_is_found = True
                    if controll_count > 1:
                        raise ValueError("Two same points have different ID s")

                # Creating a new point_id or selectin an old
                if p_is_found:
                    p = Geometry.Point(id_p_old, x, y, z)
                else:
                    id_p += 1
                    p = Geometry.Point(id_p, x, y, z)
                    tmp_p_list.append(p)

                # Resulting point
                t.points.append(p)
        i_file.close()

        if id_s== 0 or id_t== 0 or id_p== 0:
            raise ValueError("Fileformat STL does not match: Define Solid-->Faces-->Vertexes")
        print("STL-File succesfully imported")
        print("Solids: ", id_s)
        print("Triangles", id_t)
        print("Different Vertices", id_p)


class CCX_Inp_File(File):
    """ Calculix input file

    :param ID (int): Id of the file
    :param Filepath (str): Path of the file

    Example for creating an CCX_Inp_File-object

    >>> file1 = CCX_Inp_File(1, "./foo.inp")

    .. note::
        This file is for used for importing and exporting
        FEM-Data Structures in CalculiX-Format
    """
    def __init__(self, ID=None, Filepath=None):
        File.__init__(self, ID, Filepath)
        self.__elements = []
        self.__nodes = []
        self.__materials = []
        self.__solid_sections = []
        self.__elsets = []


    @property
    def solid_sections(self):
        """
        :return: All solid objects which are imported
        """
        return self.__solid_sections


    @property
    def elsets(self):
        """
        :return: All solid objects which are imported
        """
        return self.__elsets

    @property
    def elements(self):
        """
        :return: All solid objects which are imported
        """
        return self.__elements

    @property
    def nodes(self):
        """
        :return: All solid objects which are imported
        """
        return self.__nodes

    @property
    def materials(self):
        """
        :return: All solid objects which are imported
        """
        return self.__materials

    def __remove_control_chars(self, string):
        """ Removes , \n \t = spaces from a string

        :param string: String which should be cleand
        :return: Cleand string
        """
        new_string = ""
        for letter in string:
            if letter == ",":
                continue
            if letter == "\n":
                continue
            if letter == "\t":
                continue
            if letter == "=":
                continue
            if letter == " ":
                continue
            new_string += letter
        return new_string

    def read(self):
        if not os.path.isfile(self.filepath):
            raise ValueError("Given file doesnt exist %f", self.filepath)
        print ("Import element, nodes and material from: ", self.filepath)
        i_file = open(self.filepath, "r")
        nodes = []
        elements = []
        tmp_solid_sections = []
        solid_sections = []
        materials = []
        elsets = []
        e_list = []
        e_sets = []
        e_dic = {}
        mat_count = 0
        mat_next = 1
        el_count = 0
        el_next = 1
        start_key = ["*MATERIAL", "*NODE", "*ELEMENT", "*SOLID SECTION",
                    "*ELASTIC", "*DENSITY", "*CONDUCTIVITY", "*ELSET"]
        break_key = "*"
        type_key = "TYPE"
        name_key = "NAME"
        elset_key = "ELSET"
        mat_key = "MATERIAL"
        material_is_active = False
        element_is_active = False
        node_is_active = False
        elastic_is_active = False
        density_is_active = False
        conductivity_is_active = False
        solid_section_is_active = False
        elset_is_active = False
        element_elset = False
        mat_name = ""
        elem_type = ""
        s_elset_name = ""
        s_mat_name = ""
        n_dic = {}
        for line in i_file:

            line = line[0:-1]
            if len(line) == 0:
                continue
            if len(line) >= 2:
                if line[0:1] == "**":
                    #Jump over comments
                    continue

            # Break the reading if a new section is starting
            if line[0] == "*":
                element_is_active = False
                node_is_active = False
                elastic_is_active = False
                density_is_active = False
                conductivity_is_active = False
                solid_section_is_active = False
                elset_is_active = False
                element_elset = False

            # Importing elements
            if element_is_active:
                words = line.split(",")
                elem = Geometry.Element()
                elem.type = elem_type
                elem_id_first = True
                for word in words:
                    word = self.__remove_control_chars(word)
                    if len(word) == 0:
                        continue
                    if elem_id_first:
                        elem.id = int(word)
                        elem_id_first = False
                    else:
                        elem.nodeList.append(int(word))
                e_dic[elem.id] = elem
                elements.append(elem)

            # Importing nodes
            if node_is_active:
                words = line.split(",")
                node = Geometry.Node()
                node.id = int(words[0])
                node.x = float(words[1])
                node.y = float(words[2])
                node.z = float(words[3])
                n_dic[node.id] = node
                nodes.append(node)

            # Importing material Data
            if material_is_active:
                material = Material.Material()
                material.name = mat_name
                material_is_active = False

            # Importing elastic material data
            if elastic_is_active:
                words = line.split(",")
                mat_val = []
                for word in words:
                    word = self.__remove_control_chars(word)
                    try:
                        mat_val.append(float(word))
                    except:
                        pass
                material.e_modul.append(mat_val)

            # Importing density material data
            if density_is_active:
                words = line.split(",")
                mat_val = []
                for word in words:
                    word = self.__remove_control_chars(word)
                    try:
                        mat_val.append(float(word))
                    except:
                        pass
                material.density.append(mat_val)

            # Importing condictivity material data
            if conductivity_is_active:
                words = line.split(",")
                mat_val = []
                for word in words:
                    word = self.__remove_control_chars(word)
                    try:
                        mat_val.append(float(word))
                    except:
                        pass
                material.conductivity.append(mat_val)

            # Importing element sets
            if elset_is_active:
                words = line.split(",")
                if not element_elset:
                    for word in words:
                        word = self.__remove_control_chars(word)
                        if word.isdigit():
                            e_list.append(int(word))
                        else:
                            e_sets.append(word)
                else:
                    if words[0].isdigit():
                        e_list.append(int(words[0]))


            if solid_section_is_active:
                pass
            # Section is found
            for key in start_key:
                if key in line.upper():
                    # Finding material section
                    if key == "*MATERIAL":
                        # If more than 1 material is defined
                        if mat_count == mat_next:
                            materials.append(material)
                        mat_count += 1
                        material_is_active = True
                        words = line.split(",")
                        for word in words:
                            if name_key in word.upper():
                                word_s = word.split("=")
                                mat_name = word_s[1]
                                mat_name = self.__remove_control_chars(mat_name)
                        if not mat_name:
                            raise ValueError("No material name is found in line: ", line)
                    elif key == "*ELASTIC":
                        elastic_is_active = True
                    elif key == "*DENSITY":
                        density_is_active = True
                    elif key == "*CONDUCTIVITY":
                        conductivity_is_active = True
                    elif key == "*SOLID SECTION":
                        solid_section_is_active  = True
                        words = line.split(",")
                        for word in words:
                            if elset_key in word.upper():
                                word_s = word.split("=")
                                s_elset_name = word_s[1]
                            if mat_key in word.upper():
                                word_s = word.split("=")
                                s_mat_name = word_s[1]
                        tmp_solid_sections.append([s_elset_name, s_mat_name])

                    # Finding node section
                    elif key == "*NODE" and "*NODE FILE" not in line.upper() and "*NODE PRINT" not in line.upper():
                        node_is_active = True
                    elif key == "*ELSET":
                        # If more than 1 element set
                        if el_count == el_next:
                            e_set = Elset.Elset()
                            e_set.name = e_name
                            e_set.elements = e_list
                            e_set.sets = e_sets
                            elsets.append(e_set)
                            e_list = []
                            e_sets = []
                        el_count += 1
                        elset_is_active = True
                        words = line.split(",")
                        for word in words:
                            if elset_key in word.upper() and "*" not in word:
                                word_s = word.split("=")
                                e_name = word_s[1]
                                e_name = self.__remove_control_chars(e_name)
                        if not e_name:
                            raise ValueError("No elset name is found: ", line)

                    # Finding element section (we need the type aswell)
                    elif key == "*ELEMENT":
                        element_is_active = True
                        words = line.split(",")
                        for word in words:
                            if type_key in word.upper():
                                word_s = word.split("=")
                                elem_type = word_s[1]

                            if elset_key in word.upper():
                                el_count += 1
                                elset_is_active = True
                                word_s = word.split("=")
                                e_name = word_s[1]
                                e_name = self.__remove_control_chars(e_name)
                                element_elset = True
                        if not elem_type:
                            raise ValueError("No element type is found in line: ", line)
        i_file.close()
        if mat_count != 0:
            materials.append(material)

        # Append the element set if only 1 is selected
        if el_count != 0:
            e_set = Elset.Elset()
            e_set.name = e_name
            e_set.elements = e_list
            e_set.sets = e_sets
            elsets.append(e_set)


        # Change the settings from dictonary to an list of element objects (references)
        for e_set in elsets:
            e_list = []
            # Search for element objects which we transfer into
            for e_id in e_set.elements:
                 e_list.append(e_dic[e_id])
            e_set.elements = e_list

        # Adding all elements from *elset, e_set
        #                          e_set_2
        for e_set in elsets:
            for set in e_set.sets:
                for e_set_2 in elsets:
                    if e_set_2.name == set:
                        e_set.elements.extend(e_set_2.elements)

        for section in tmp_solid_sections:
            mat_name = section[1]
            set_name = section[0]
            s_section = SolidSection.SolidSection()
            for mat in materials:
                if mat_name == mat.name:
                    s_section.material = mat
            for e_set in elsets:
                if set_name == e_set.name:
                    s_section.elset = e_set
            solid_sections.append(s_section)

        for elem in elements:
            node_list = []
            for node_id in elem.nodeList:
                node_list.append(n_dic[node_id])
            elem.nodeList = node_list
            xc = 0.0
            yc = 0.0
            zc = 0.0
            for node in node_list:
                xc += node.x
                yc += node.y
                zc += node.z
            elem.xc = xc/len(node_list)
            elem.yc = yc/len(node_list)
            elem.zc = zc/len(node_list)


        # Saving the imported data into the object
        if len(elements) == 0:
            print ("No elements were found")
        else:
            print ("Elements were imported: ", len(elements))
            self.__elements = elements
        if len(nodes) == 0:
            print ("No nodes were found")
        else:
            print ("Nodes were imported: ", len(nodes))
            self.__nodes = nodes
        if len(materials) == 0:
            print ("No materials were found")
        else:
            print ("Materials were imported: ", len(materials))
            self.__materials = materials

        if len(elsets) == 0:
            print("No elements ets were defined")
        else:
            print("Elementsets were imported: ", len(elsets))
            self.__elsets = elsets

        if len(solid_sections) == 0:
            print("No solid sections were defined")
        else:
            print("Solid sections were imported: ", len(solid_sections))
            self.__solid_sections = solid_sections

    def export_mod_inp_topo_mat(self, new_file, mat_models, output_nodes, node_output_request):
        """ We create a new inputfile with new material law

        :param new_file: File path for the new file
        """
        if not os.path.isfile(self.filepath):
            raise ValueError("Given file doesnt exist %f", self.filepath)
        print ("Import element, nodes and material from: ", self.filepath)
        i_file = open(self.filepath, "r")
        o_file = open(new_file, "w")
        key = "*SOLID SECTION"
        o_key = "*END STEP"
        jump_key = "*NODE PRINT"
        add_topo_mat_is_active = True
        jump_old_output = False
        for line in i_file:
            if key in line.upper():
                # Define the material only one time in the model part
                if add_topo_mat_is_active:
                    for mat_model in mat_models:
                        # Adding new material in the model

                        for topo_mat in mat_model.topo_materials:
                            # Creat the material type of the model
                            o_file.write("*Material, name=" + topo_mat.name + "\n")
                            # Export the material properties
                            for mat_list in topo_mat.e_modul:
                                o_file.write("*Elastic\n")
                                for mat_val in mat_list:
                                    o_file.write(str(mat_val) + ",")
                                o_file.write("\n")
                            # Export the material properties
                            for mat_list in topo_mat.conductivity:
                                o_file.write("*Conductivity\n")
                                for mat_val in mat_list:
                                    o_file.write(str(mat_val) + ",")
                                o_file.write("\n")
                            # Export the material properties
                            for mat_list in topo_mat.density:
                                o_file.write("*Density\n")
                                for mat_val in mat_list:
                                    o_file.write(str(mat_val) + ",")
                                o_file.write("\n")

                        # Creating new element sets and solid sections

                        for s_section in mat_model.topo_solid_sections:

                            # Start creating the element set for the solid section
                            o_file.write("*Elset, elset=" + s_section.elset.name + "\n")
                            tab_count = 0
                            for elem in s_section.elset.elements:
                                o_file.write(str(elem.id) + ",")
                                tab_count += 1
                                if tab_count == 7:
                                    tab_count = 0
                                    # New line after 8 elements
                                    o_file.write("\n")
                            # New line after some elements
                            if tab_count != 0:
                                o_file.write("\n")
                            # Creating the solid section

                            o_file.write("*Solid Section, elset=" + s_section.elset.name + ", material=" + s_section.material.name + "\n")
                    o_file.write("*Nset, Nset=Nall_topo_output\n")
                    tab_count = 0
                    for node in output_nodes:
                        o_file.write(str(node.id) + ",")
                        tab_count += 1
                        if tab_count == 7:
                            tab_count = 0
                            o_file.write("\n")
                    if tab_count != 0:
                        o_file.write("\n")

                add_topo_mat_is_active = False
                continue
            # Creating the output requests
            if o_key in line.upper():
                add_output = True
                o_file.write("*Node Print, Nset=Nall_topo_output\n")
                o_file.write(node_output_request + "\n")


            if jump_key in line.upper():
                jump_old_output = True
                continue
            if jump_old_output:
                jump_old_output = False
                continue

            o_file.write(line)
        o_file.close()
        i_file.close()

    def export_mod_inp_topo_sens(self, new_file, nodes, elements, element_output_request):

        if not os.path.isfile(self.filepath):
            raise ValueError("Given file doesnt exist %f", self.filepath)
        print ("Import element, nodes and material from: ", self.filepath)

        i_file = open(self.filepath, "r")
        o_file = open(new_file, "w")
        jump_key = "*EL PRINT"
        jump_key2 = "*BOUNDARY"
        bound_key = "*BOUNDARY"
        last_key = "*END STEP"
        create_eall_set = False
        add_1_time = True
        ignore_case = False
        add_boundary = True
        for line in i_file:

            if line[0] == "*":
                if len(line) >= 2:
                    if not (line[1] == "*"):
                        ignore_case = False

            if jump_key in line.upper():
                ignore_case = True

            if jump_key2 in line.upper():
                ignore_case = True

            if ignore_case:
                continue
            if "*SOLID SECTION" in line.upper():
                create_eall_set = True
            if create_eall_set and add_1_time:
                add_1_time = False
                create_eall_set = False
                o_file.write("*ELSET, ELSET=Eall_topo_output\n")
                tab_count = 0
                for elem in elements:
                    o_file.write(str(elem.id) + ",")
                    tab_count += 1
                    if tab_count == 7:
                        tab_count = 0
                        o_file.write("\n")
                if tab_count != 0:
                    o_file.write("\n")
            # Adding boundary values
            if bound_key in line.upper() and add_boundary:
                o_file.write("*BOUNDARY\n")
                for node in nodes:
                    o_file.write(str(node.id) + ", 1, 1, " + str(node.u_x))
                    o_file.write("\n")
                    o_file.write(str(node.id) + ", 2, 2, " + str(node.u_y))
                    o_file.write("\n")
                    o_file.write(str(node.id) + ", 3, 3," + str(node.u_z))
                    o_file.write("\n")
                add_boundary = False
            if last_key in line.upper() and add_boundary:
                o_file.write("*BOUNDARY\n")
                
                for node in nodes:
                    o_file.write(str(node.id) + ", 1, 1, " + str(node.u_x))
                    o_file.write("\n")
                    o_file.write(str(node.id) + ", 2, 2, " + str(node.u_y))
                    o_file.write("\n")
                    o_file.write(str(node.id) + ", 3, 3, " + str(node.u_z))
                    o_file.write("\n")
                add_boundary = False

            if last_key in line.upper():
                o_file.write("*EL PRINT, ELSET = Eall_topo_output\n")
                o_file.write(element_output_request + "\n")
            o_file.write(line)




class CCX_Dat_File(File):
    """ Calculix result file

    :param ID (int): Id of the file
    :param Filepath (str): Path of the file

    Example for creating a CCX_Dat_File-Object

    >>> file1 = CCX_Inp_File(1, "./foo.dat")

    .. note::
        This file is for used for importing the results
        from CalculiX calculations
    """
    def __init__(self, ID=None, Filepath=None):
        File.__init__(self, ID, Filepath)



    def add_results(self, nodes, elements, input_requests):
        if not os.path.isfile(self.filepath):
            raise ValueError("Given file doesnt exist %f", self.filepath)
        print ("Import results from: ", self.filepath)
        i_file = open(self.filepath, "r")
        u_key = "DISPLACEMENTS"
        ener_key = "ENERGY DENSITY"
        read_disp = False
        read_ener = False
        jump = False
        # Transform elements and nodes into dictonary for faster access:
        n_dic = {}
        e_dic = {}
        for node in nodes:
            n_dic[node.id] = node
        for elem in elements:
            e_dic[elem.id] = elem

        for line in i_file:
            line = line[0:-1]

            for input in input_requests:

                if jump:
                    jump = False
                    continue
                    
                if len(line) == 0:
                    continue
                if input == "u":
                
                    if u_key in line.upper():
                        read_disp = True
                        jump = True
                        continue
                    if read_disp:
                        words = line.split(" ")
                        words = [feld for feld in words if feld != '']
                        if len(words) >= 4:
                            node_id = int(words[0])
                            n_dic[node_id].u_x = float(words[1])
                            n_dic[node_id].u_y = float(words[2])
                            n_dic[node_id].u_z = float(words[3])
                if input == "ener":
                    if ener_key in line.upper():
                        read_ener = True
                        jump = True
                        continue
                    if read_ener:
                        
                        words = line.split(" ")
                        words = [feld for feld in words if feld != '']
                        if len(words) >= 3:
                            elem_id = int(words[0])
                            e_dic[elem_id].ener = float(words[2])
        i_file.close()


