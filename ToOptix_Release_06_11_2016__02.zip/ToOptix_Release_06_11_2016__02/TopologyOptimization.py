"""
.. module:: Material
    :platform: Unix, Windows Linux
    :synopsis: Modul which geometric Functions

.. module:: Martin Denk <denkmartin@web.de>


"""

import numpy as np
from . import Material
from . import Elset
from . import SolidSection

class MaterialModel():
    def __init__(self):
        self.__set_number = 10
        self.__material = None
        self.__topo_materials = []
        self.__elset = []
        self.__topo_elsets = []
        self.__topo_solid_sections = []
        self.__penalty_factor = 2.5

    @property
    def topo_elsets(self):
        return self.__topo_elsets
    @property
    def topo_solid_sections(self):
        return self.__topo_solid_sections
        
    @topo_solid_sections.setter
    def topo_solid_sections(self, topo_solid_sections):
        self.__topo_solid_sections = topo_solid_sections

    @property
    def topo_materials(self):
        return self.__topo_materials

    @property
    def penalty_factor(self):
        return self.__penalty_factor

    @penalty_factor.setter
    def penalty_factor(self, Penalty_factor):
        self.__penalty_factor = Penalty_factor

    @property
    def elset(self):
        return self.__elset

    @elset.setter
    def elset(self, elset):
        self.__elset = elset

    @property
    def set_number(self):
        return self.__set_number

    @ set_number.setter
    def set_number(self, set_number):
        self.__set_number = set_number

    @property
    def material(self):
        return self.__material

    @ material.setter
    def material(self, material):
        self.__material = material

    def define_new_properties(self, mat_list, scale_fac):
        mat_new_list = []
        change_first = True
        for mat_val in mat_list:
            if change_first:
                mat_scale = scale_fac ** self.penalty_factor * mat_val
                change_first = False
                mat_new_list.append(mat_scale)
                continue
            mat_new_list.append(mat_val)
        return mat_new_list

    def define_topo_materials(self):
        """ This method generates a lot of material-set propertys

        """
        # Create materials with exponential material changing
        for count in range(self.__set_number):

            # Define new material
            topo_mat = Material.Material()
            topo_mat.name = self.material.name + "tp_mat_" + str(count)
            scale_fac = float(count+1)/float(self.__set_number)

            # Change elastic values
            for mat_list in self.material.e_modul:
                new_mat_list = self.define_new_properties(mat_list, scale_fac)
                topo_mat.e_modul.append(new_mat_list)

            # Change conductivity values
            for mat_list in self.material.conductivity:
                new_mat_list = self.define_new_properties(mat_list, scale_fac)
                topo_mat.conductivity.append(new_mat_list)

            # Change density value
            for mat_list in self.material.density:
                new_mat_list = self.define_new_properties(mat_list, scale_fac)
                topo_mat.density.append(new_mat_list)
            self.topo_materials.append(topo_mat)

    def define_sets_for_material_distribution(self):
        """ Sorting the elements into different sets for creating the denstiy

        :return:
        """
        #
        #self.topo_materials = []
        # Sorting elements into several compaction sets
        self.topo_solid_sections = []
        e_sets = []
        for tmp in range(self.set_number):
            e_sets.append([])
        for elem in self.elset.elements:
            index = int(float(elem.compaction) * float(len(self.topo_materials)-1))
            e_sets[index].append(elem)
        # Exporting the element sets start with the lowest value:
        count = 0
        for e_set in e_sets:
            if len(e_set) > 0:
                elset = Elset.Elset()
                elset.name = self.elset.name + "tp_mat_" + str(count)
                elset.elements = e_set
                self.topo_elsets.append(elset)
                s_section = SolidSection.SolidSection()
                s_section.elset = elset
                s_section.material = self.topo_materials[count]

                self.topo_solid_sections.append(s_section)
            count += 1


class MethodOfMovingAsymptotes():

    def __init__(self):
        self.__move = 0.2
        self.__solution_criteria = "SIMP"
        self.__residuum = 0.01
        self.__compaction = []
        self.__vol_ratio = 0.3

    @property
    def move(self):
        return self.__move

    @property
    def residuum(self):
        return self.__residuum

    @property
    def solution_criteria(self):
        return self.__solution_criteria

    @property
    def vol_ratio(self):
        return self.__vol_ratio

    @ vol_ratio.setter
    def vol_ratio(self, Vol_ratio):
        self.__vol_ratio = Vol_ratio

    @property
    def compaction(self):
        return self.__compaction
        
    @ compaction.setter
    def compaction(self, compaction):
        self.__compaction = compaction

    def change_compaction(self, old_compaction, sensitivity, material_models):
        # -----
        # Starting method of moving asympthoes
        # -----
        # Setting new compaction
        self.compaction = old_compaction
        penal = material_models[0].penalty_factor
        old_density = np.array(old_compaction)
        sensitivity = np.array(sensitivity)

        sensitivity = -0.5*(penal * old_density **(penal - 1.0) * (70000.0 - 1.5) * sensitivity)
        # Move the sensitivitys to positive values
        sensitivity = abs(sensitivity)
        l2 = max(sensitivity)
        l1 = min(sensitivity)
        while abs(l2-l1) > (self.residuum*l2):
            lmid = 0.5 * (l2 + l1)
            if(self.solution_criteria  == "SIMP"):

                # Criteria like M.P. Bendsoe SIMP
                self.compaction = np.maximum (0.0, np.maximum(old_density - self.move, np.minimum(1.0,
                    np.minimum(old_density + self.move, old_density * (sensitivity / lmid) ** 0.5))))


            elif (self.solution_criteria == "BESO"):

                # Criteria like X. Huang ESO/BESO
                self.compaction = np.maximum(0.0, np.sign(sensitivity - lmid))

            else:
                print("Unknown solution criteria automatic change to BESO")
                self.__solution_criteria = "BESO"
                self.compaction = np.maximum(self.__mat_min, np.sign(sensitivity - lmid))
            if np.mean(self.compaction) - self.vol_ratio > 0.0:
                l1 = lmid
            else:
                l2 = lmid

class TopologyOptimization(object):

    def __init__(self):
        self.density = None
        self.init_density = None
        self.sensitivity = None
        self.penalty_exponent = 3.0
        self.volumina_ratio = 0.3

    @property
    def density(self):
        return self.__density


    @ density.setter
    def density(self, density):
        self.__density = density

    @property
    def init_density(self):
        return self.__init_density

    @ init_density.setter
    def init_density(self, Init_density):
        self.__init_density = Init_density

    @property
    def sensitivity(self):
        return self.__sensitivity

    @ sensitivity.setter
    def sensitivity(self, sensitivity):
        self.__sensitivity = sensitivity

    @property
    def penalty_exponent(self):
        return self.__penalty_exponent

    @ penalty_exponent.setter
    def penalty_exponent(self, penalty_exponent):
        self.__penalty_exponent = penalty_exponent

    @property
    def volumina_ratio(self):
        return self.__volumina_ratio

    @ volumina_ratio.setter
    def volumina_ratio(self, volumina_ratio):
        self.__volumina_ratio = volumina_ratio
